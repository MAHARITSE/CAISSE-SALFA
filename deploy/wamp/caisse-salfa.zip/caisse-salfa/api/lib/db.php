<?php
/**
 * Accès MySQL : connexion PDO, transactions verrouillées et lecture du snapshot.
 */

declare(strict_types=1);

function salfa_pdo(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $c = salfa_config();
    $base = salfa_nom_base_sur();
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['hote'], (int) $c['port'], $base);
    try {
        $pdo = new PDO($dsn, (string) $c['utilisateur'], (string) $c['mot_de_passe'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
            PDO::ATTR_TIMEOUT => 5,
        ]);
    } catch (PDOException $e) {
        $detail = (bool) salfa_config()['debug'] ? ' ' . $e->getMessage() : '';
        $code = (int) $e->getCode();
        // 1049 (base absente) et 1045 (droits) sont traités par l'amorçage :
        // l'écran de connexion propose alors la saisie des accès MySQL.
        throw new SalFaErreur(
            (($code === 1049 || str_contains($e->getMessage(), 'Unknown database'))
                ? 'La base « ' . $base . ' » n’existe pas encore sur ce serveur.'
                : 'Connexion à MySQL impossible. Vérifiez que WampServer est démarré (icône verte) et que MySQL tourne.')
            . $detail,
            503,
            $code === 1049 || str_contains($e->getMessage(), 'Unknown database') ? 'base_absente' : 'base_indisponible'
        );
    }
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED");
    return $pdo;
}

function salfa_table(string $nom): string
{
    return '`' . salfa_prefixe() . $nom . '`';
}

function salfa_executer(string $sql, array $parametres = []): PDOStatement
{
    $requete = salfa_pdo()->prepare($sql);
    $requete->execute($parametres);
    return $requete;
}

/** Verrou de ligne : deux onglets ne peuvent pas s'écraser entre eux. */
function salfa_verrouiller_livre(): null
{
    $sql = 'SELECT id FROM ' . salfa_table('livre') . ' WHERE id = 1 FOR UPDATE';
    $ligne = salfa_pdo()->query($sql)->fetch();
    if (!$ligne) {
        throw new SalFaErreur('Le livre de caisse n’est pas initialisé : la base existe mais ses tables sont incomplètes. Recopiez le dossier complet du site (sql/ compris).', 500, 'livre_absent');
    }
    return null;
}

/**
 * Charge le livre complet au format attendu par l'application (Sauvegarde).
 *
 * @return array<string, mixed>
 */
/**
 * Ajoute la colonne des images libres de l'en-tête à une base déjà installée.
 *
 * `CREATE TABLE IF NOT EXISTS` ne touche pas une table existante : sans cette
 * migration, un site mis à jour garderait un en-tête sans images. L'opération
 * est idempotente et silencieuse en cas de droits insuffisants : l'en-tête
 * reste alors utilisable en mode « textes ».
 */
function salfa_migrer_images_entete(): void
{
    static $faite = false;
    if ($faite) {
        return;
    }
    $faite = true;
    try {
        $colonnes = salfa_pdo()->query('SHOW COLUMNS FROM ' . salfa_table('entetes') . " LIKE 'images'")->fetchAll();
        if ($colonnes === []) {
            salfa_pdo()->exec('ALTER TABLE ' . salfa_table('entetes') . ' ADD COLUMN images MEDIUMTEXT NULL AFTER lignes');
        }
    } catch (Throwable $e) {
        // Base en lecture seule ou droits limités : on continue sans images libres.
    }
}

function salfa_charger_livre(): array
{
    salfa_migrer_images_entete();
    $pdo = salfa_pdo();
    $libre = $pdo->query('SELECT * FROM ' . salfa_table('livre') . ' WHERE id = 1')->fetch();
    if (!$libre) {
        throw new SalFaErreur('Le livre de caisse n’est pas initialisé : la base existe mais ses tables sont incomplètes. Recopiez le dossier complet du site (sql/ compris).', 500, 'livre_absent');
    }
    $parametres = $pdo->query('SELECT * FROM ' . salfa_table('parametres') . ' WHERE id = 1')->fetch() ?: [];
    $masques = $pdo->query('SELECT * FROM ' . salfa_table('masques') . ' ORDER BY ordre, id')->fetchAll();
    $compteurs = $pdo->query('SELECT * FROM ' . salfa_table('compteurs') . ' ORDER BY cle')->fetchAll();
    $ecritures = $pdo->query('SELECT * FROM ' . salfa_table('ecritures') . ' ORDER BY date, cree_le, id')->fetchAll();
    $details = $pdo->query('SELECT * FROM ' . salfa_table('details') . ' ORDER BY ecriture_id, ordre, id')->fetchAll();
    $clotures = $pdo->query('SELECT * FROM ' . salfa_table('clotures') . ' ORDER BY annee')->fetchAll();

    $parEcriture = [];
    foreach ($details as $d) {
        $parEcriture[$d['ecriture_id']][] = [
            'id' => (string) $d['id'],
            'libelle' => (string) $d['libelle'],
            'reference' => $d['reference'] === null || $d['reference'] === '' ? null : (string) $d['reference'],
            'montant' => (int) $d['montant'],
            '_ordre' => (int) $d['ordre'],
        ];
    }

    $ecrituresParAnnee = [];
    foreach ($ecritures as $e) {
        $item = [
            'id' => (string) $e['id'],
            'numero' => (string) $e['numero'],
            'date' => (string) $e['date'],
            'sens' => (string) $e['sens'],
            'libelle' => (string) $e['libelle'],
            'categorie' => (string) $e['categorie'],
            'montant' => (int) $e['montant'],
            'createdAt' => salfa_iso((string) $e['cree_le']),
        ];
        if ($e['tiers'] !== null && $e['tiers'] !== '') {
            $item['tiers'] = (string) $e['tiers'];
        }
        if ($e['reference'] !== null && $e['reference'] !== '') {
            $item['reference'] = (string) $e['reference'];
        }
        if ($e['observation'] !== null && $e['observation'] !== '') {
            $item['observation'] = (string) $e['observation'];
        }
        if ($e['modifie_le'] !== null) {
            $item['updatedAt'] = salfa_iso((string) $e['modifie_le']);
        }
        $lignes = $parEcriture[$e['id']] ?? [];
        if ($lignes) {
            foreach ($lignes as &$l) {
                unset($l['_ordre']);
            }
            unset($l);
            $item['lignesDetail'] = $lignes;
        }
        if ($e['annee_archive'] !== null) {
            $ecrituresParAnnee[(int) $e['annee_archive']][] = $item;
        } else {
            $ecrituresParAnnee['courant'][] = $item;
        }
    }

    $masquesFormates = [];
    $parMasque = [];
    if ($masques) {
        $ids = array_column($masques, 'id');
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $lignesMasques = salfa_executer(
            'SELECT * FROM ' . salfa_table('masque_lignes') . " WHERE masque_id IN ($placeholders) ORDER BY masque_id, ordre, id",
            array_values($ids)
        )->fetchAll();
        foreach ($lignesMasques as $l) {
            $parMasque[$l['masque_id']][] = [
                'description' => (string) $l['description'],
                'montantDefaut' => $l['montant_defaut'] === null ? null : (int) $l['montant_defaut'],
            ];
        }
        foreach ($masques as $m) {
            $lignes = [];
            foreach ($parMasque[$m['id']] ?? [] as $l) {
                $ligne = ['description' => $l['description']];
                if ($l['montantDefaut'] !== null) {
                    $ligne['montantDefaut'] = (int) $l['montantDefaut'];
                }
                $lignes[] = $ligne;
            }
            $masque = [
                'id' => (string) $m['id'],
                'nom' => (string) $m['nom'],
                'sens' => (string) $m['sens'],
                'lignes' => $lignes,
            ];
            if ($m['description'] !== null && $m['description'] !== '') {
                $masque['description'] = (string) $m['description'];
            }
            $masquesFormates[] = $masque;
        }
    }

    $compteursFormates = [];
    foreach ($compteurs as $c) {
        $compteursFormates[(string) $c['cle']] = (int) $c['valeur'];
    }

    $cloturesFormates = [];
    foreach ($clotures as $c) {
        $annee = (int) $c['annee'];
        $cloturesFormates[] = [
            'annee' => $annee,
            'clotureLe' => salfa_iso((string) $c['cloture_le']),
            'soldeOuverture' => (int) $c['solde_ouverture'],
            'recettes' => (int) $c['recettes'],
            'depenses' => (int) $c['depenses'],
            'soldeCloture' => (int) $c['solde_cloture'],
            'ecritures' => $ecrituresParAnnee[$annee] ?? [],
        ];
    }

    $report = null;
    if ($parametres['report_annee'] !== null && $parametres['report_solde'] !== null) {
        $report = ['annee' => (int) $parametres['report_annee'], 'solde' => (int) $parametres['report_solde']];
    }

    return [
        'format' => 'CAISSE-SALFA',
        'version' => 1,
        'revision' => (int) $libre['revision'],
        'updatedAt' => salfa_iso((string) $libre['modifie_le']),
        'ecritures' => $ecrituresParAnnee['courant'] ?? [],
        'parametres' => [
            'soldeInitial' => (int) ($parametres['solde_initial'] ?? 0),
            'exercice' => $parametres['exercice'] === null ? null : (int) $parametres['exercice'],
            'reportPrecedent' => $report,
        ],
        'masques' => $masquesFormates,
        'compteurs' => $compteursFormates,
        'exercicesClotures' => $cloturesFormates,
        // Un en-tête vide fait planter l'affichage du navigateur : on renvoie
        // toujours au moins le modèle livré (même forme que enteteParDefaut()).
        'entetes' => salfa_entetes_ou_defaut(salfa_charger_entetes()),
        'categories' => salfa_categories_ou_defaut(salfa_charger_categories()),
        ...((($user = salfa_utilisateur_courant(false)) && in_array($user['role'], ['admin', 'comptable'], true)) ? ['virements' => salfa_lire_registre_virements()] : []),
    ];
}

/**
 * En-tête renvoyé au navigateur : celui de la base, ou le modèle livré quand la
 * table est vide (base fraîche, en-tête jamais enregistré).
 *
 * Sans cela, `entetes` vaut `[]` et l'écran d'accueil casse dès la première
 * connexion sur une base neuve.
 */
function salfa_entetes_ou_defaut(array $entete): array
{
    if (!isset($entete['lignes']) || !is_array($entete['lignes']) || $entete['lignes'] === []) {
        return salfa_entete_defaut();
    }
    $entete['mode'] = ($entete['mode'] ?? 'textes') === 'image' ? 'image' : 'textes';
    $entete['image'] = is_string($entete['image'] ?? null) ? $entete['image'] : '';
    $entete['images'] = is_array($entete['images'] ?? null) ? $entete['images'] : [];
    return $entete;
}

/** Modèle d'en-tête livré, identique à `enteteParDefaut()` côté navigateur. */
function salfa_entete_defaut(): array
{
    $lignes = [
        ['FIANGONANA LOTERANA MALAGASY', 11, true],
        ['(ÉGLISE LUTHERIENNE MALGACHE - MALAGASY LUTHERAN CHURCH)', 9, false],
        ['SYNODAM-PARITANY FIHERENANA TOLIARA', 9, false],
        ['SAMPAN’ASA LOTERANA MOMBA NY FAHASALAMANA (SALFA)', 9.5, true],
        ['DEPARTEMENT DE SANTE - HEALTH DEPARTMENT', 9, false],
        ['HOPITALY LOTERANA TOLIARY TANAMBAO - BP : 99', 9.5, true],
        ['E-mail: salfa.tulear@gmail.com', 8.5, false],
    ];
    $resultat = [];
    foreach ($lignes as [$texte, $taille, $gras]) {
        $resultat[] = [
            'texte' => $texte,
            'taille' => $taille,
            'police' => 'Arial',
            'gras' => $gras,
            'italique' => false,
            'souligne' => false,
            'alignement' => 'centre',
        ];
    }
    return ['mode' => 'textes', 'image' => '', 'lignes' => $resultat, 'images' => []];
}

/**
 * Catégories renvoyées au navigateur : celles de la base, ou les listes de
 * départ quand le semis n'a pas encore eu lieu. Une liste vide bloque la
 * saisie (« la liste des catégories ne peut pas être vide »).
 */
function salfa_categories_ou_defaut(array $categories): array
{
    $recette = is_array($categories['recette'] ?? null) ? array_values($categories['recette']) : [];
    $depense = is_array($categories['depense'] ?? null) ? array_values($categories['depense']) : [];
    if ($recette !== [] && $depense !== []) {
        return ['recette' => $recette, 'depense' => $depense];
    }
    $defaut = salfa_categories_defaut();
    return [
        'recette' => $recette !== [] ? $recette : $defaut['recette'],
        'depense' => $depense !== [] ? $depense : $defaut['depense'],
    ];
}

/** Catégories livrées avec la caisse, dans l'ordre du script SQL. */
function salfa_categories_defaut(): array
{
    return [
        'recette' => ['Recettes journalières', 'Consultations', 'Pharmacie', 'Laboratoire', 'Hospitalisation', 'Maternité', 'Imagerie', 'Subventions & dons', 'Remboursements', 'Autres recettes'],
        'depense' => ['Achats médicaments', 'Consommables médicaux', 'Fournitures de bureau', 'Carburant & transport', 'Maintenance & équipements', 'Salaires & primes', 'Frais de mission', 'Honoraires', 'Eau & électricité', 'Téléphone & internet', 'Remboursements & rétrocessions', 'Versements bancaires', 'Divers'],
    ];
}

/** Horodatage MySQL (heure locale) → ISO 8601 lisible par le navigateur. */
function salfa_iso(string $mysql): string
{
    $date = DateTimeImmutable::createFromFormat('Y-m-d H:i:s.u', $mysql, new DateTimeZone((string) salfa_config()['timezone']))
        ?: DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $mysql, new DateTimeZone((string) salfa_config()['timezone']));
    if ($date === false) {
        return gmdate('c');
    }
    return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.v\Z');
}

/** Écriture d'une année clôturée : refuse toute modification. */
function salfa_verifier_non_archive(string $ecritureId): void
{
    $ligne = salfa_executer(
        'SELECT annee_archive, numero FROM ' . salfa_table('ecritures') . ' WHERE id = ?',
        [$ecritureId]
    )->fetch();
    if ($ligne && $ligne['annee_archive'] !== null) {
        throw new SalFaErreur(
            'La pièce ' . $ligne['numero'] . ' appartient à l’exercice ' . $ligne['annee_archive'] . ' clôturé : elle ne peut plus être modifiée.',
            409,
            'exercice_archive'
        );
    }
}

function salfa_revision_attendue(array $corps): int
{
    if (!array_key_exists('revision', $corps)) {
        throw new SalFaErreur('Révision attendue manquante : rechargez la page.', 400, 'revision_manquante');
    }
    $revision = $corps['revision'];
    if (!is_int($revision) && !(is_string($revision) && preg_match('/^\d+$/', $revision))) {
        throw new SalFaErreur('Révision invalide.', 400, 'revision_invalide');
    }
    return (int) $revision;
}

function salfa_verifier_revision(int $attendue): void
{
    salfa_verrouiller_livre();
    $reelle = (int) salfa_pdo()->query('SELECT revision FROM ' . salfa_table('livre') . ' WHERE id = 1')->fetchColumn();
    if ($attendue !== $reelle) {
        throw new SalFaErreur(
            'Le livre a été modifié dans un autre onglet ou par un autre utilisateur. Rechargez les données avant d’enregistrer.',
            409,
            'conflit_revision'
        );
    }
}

function salfa_incrementer_revision(): int
{
    $pdo = salfa_pdo();
    $pdo->exec('UPDATE ' . salfa_table('livre') . ' SET revision = revision + 1, modifie_le = NOW(3) WHERE id = 1');
    return (int) $pdo->query('SELECT revision FROM ' . salfa_table('livre') . ' WHERE id = 1')->fetchColumn();
}

/** Exécute une mutation dans une transaction verrouillée et renvoie le livre à jour. */
function salfa_transaction(callable $action): array
{
    $pdo = salfa_pdo();
    $pdo->beginTransaction();
    try {
        $resultat = $action();
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
    $livre = salfa_charger_livre();
    if (is_array($resultat) && isset($resultat['livre']) && is_array($resultat['livre'])) {
        $livre = array_merge($livre, $resultat['livre']);
    }
    return $livre;
}
